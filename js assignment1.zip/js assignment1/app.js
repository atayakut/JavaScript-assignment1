document.addEventListener('DOMContentLoaded', function () {
    // Arrays for generating random phrases
    const nouns = ["cat", "dog", "tree", "book", "house"];
    const verbs = ["run", "jump", "read", "eat", "sleep"];
    const adjectives = ["happy", "sad", "big", "small", "colorful"];
    const places = ["park", "beach", "forest", "city", "mountain"];

    let textToSpeak = "";

    // Function to generate random word from an array
    function getRandomWord(wordArray) {
        return wordArray[Math.floor(Math.random() * wordArray.length)];
    }

    // Function to update textToSpeak
    function updateTextToSpeak() {
        textToSpeak = `${getRandomWord(nouns)} ${getRandomWord(verbs)} ${getRandomWord(adjectives)} ${getRandomWord(nouns)} ${getRandomWord(places)}`;
    }

    // Button event listeners
    document.getElementById('btn1').addEventListener('click', function () {
        textToSpeak += getRandomWord(nouns) + " ";
    });

    document.getElementById('btn2').addEventListener('click', function () {
        textToSpeak += getRandomWord(verbs) + " ";
    });

    document.getElementById('btn3').addEventListener('click', function () {
        textToSpeak += getRandomWord(adjectives) + " ";
    });

    document.getElementById('btn4').addEventListener('click', function () {
        textToSpeak += getRandomWord(places) + " ";
    });

    document.getElementById('btn5').addEventListener('click', function () {
        updateTextToSpeak();
        speakNow();
        outputTextToSpeak(); // Output the text in a text format
    });

    document.getElementById('resetBtn').addEventListener('click', function () {
        textToSpeak = "";
        outputTextToSpeak(); // Reset text output
    });

    document.getElementById('speakBtn').addEventListener('click', function () {
        speakNow();
    });

    // Function to output the text
    function outputTextToSpeak() {
        console.log("Generated Text: ", textToSpeak);
        // You can modify this to display the text on the webpage if needed.
    }
});
